<?php


return [
        'titles'        => [
            'warehouse'     => ' تقرير وارد المخزن ',
            'warehouse.outcome'    => ' تقرير صادر المخزن ',
            'sales'    => ' تقرير المبيعات ',
        ],
        
        'name'                    => 'اسم المنتج',
        'date'                    => 'التاريخ',
        'ordercount'                    => 'عدد الطلبات',
        'ordersum'                    => ' اجمالي المبيعات',
        'subcategory_id'               => 'القسم الفرعي',
        'type'                   => ' نوع المنتج',
        'price'                   => ' سعر المنتج',
        'quantity'                   => ' الكمية ',
];
