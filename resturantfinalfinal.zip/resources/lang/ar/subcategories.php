<?php

return [
        'titles'        => [
            'index'     => ' الأقسام الفرعية',
            'create'    => ' إضافة قسم فرعي ',
            'edit'      => 'تعديل  القسم فرعي  ',
            'show'      => ' عرض  القسم فرعي  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل  قسم فرعي   بنجاح',
            'updated_succesfully' => 'تم تعديل  القسم فرعي بنجاح',
            'deleted_succesfully' => 'تم حذف  القسم فرعي بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'name'                   => ' الاسم ',
        'category_id'            => ' القسم الرئيسي ',
];
