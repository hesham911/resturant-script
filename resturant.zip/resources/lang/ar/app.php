<?php

return [
    'forms'     => [
        'btn'      =>[
            'FormSubmit'            => ' تأكيد ',
            'edit'                  => ' تعديل ',
            'add'                   => ' إضافة ',
            'delete'                => ' حذف ',
        ],
    ],
    'tables'    =>[
            'control'  => 'التحكم',
            'num'      => 'التسلسل',
            'btn'      =>[
            'delete'                => 'حذف',
            'edit'                  => 'تعديل',
        ]
    ],
    'menu'  =>[
        'show_all'     => 'عرض الكل',
        'add_new'      => ' إضافة جديد  ',
    ],
];
