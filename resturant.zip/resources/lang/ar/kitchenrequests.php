<?php

return [
        'titles'        => [
            'index'     => ' طلبات التوريد ',
            'create'    => ' إضافة طلب توريد ',
            'edit'      => 'تعديل  طلب التوريد  ',
            'show'      => ' عرض  طلب التوريد  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل  طلب توريد   بنجاح',
            'updated_succesfully' => 'تم تعديل  طلب التوريد بنجاح',
            'deleted_succesfully' => 'تم حذف  طلب التوريد بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'employee_id'                => ' الموظف ',
        'material_id'                => ' المادة الخام ',
        'quantity'                => ' الكمية ',
        'status'                => ' الحالة ',
        'total_cost'                => ' اجمالي التكلفة  ',
];
