<?php

return [

    'zones' =>[
        'titles'            => [
            'index'                 => ' المناطق ',
            'create'                => ' إضافة المنطقة ',
            'subcreate'             => 'إضافة منطقة جديدة',
            'edit'                  => 'تعديل  المنطقة  ',
            'show'                  => ' عرض  المنطقة  ',
        ],
        'placeholder'       => [
            'name'                  => ' اسم المنطقة ',
            'price'                 => ' سعر التوصيل للمنزل ',
        ],
        'massages'          => [
            'created_successfully'   => 'تم  تسجيل  المنطقة   بنجاح',
            'updated_successfully'   => 'تم تعديل  المنطقة بنجاح',
            'deleted_check'          => 'هل تريد حقا حذف هذة المنطقة',
            'deleted_successfully'   => 'تم حذف  المنطقة بنجاح',
            'error_successfully'     => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'name'                       => ' الاسم ',
        'price'                      => ' السعر ',
    ],
];