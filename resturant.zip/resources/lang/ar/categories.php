<?php

return [
        'titles'        => [
            'index'     => ' الأقسام ',
            'create'    => ' إضافة قسم ',
            'edit'      => 'تعديل  القسم  ',
            'show'      => ' عرض  القسم  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل  قسم   بنجاح',
            'updated_succesfully' => 'تم تعديل  القسم بنجاح',
            'deleted_succesfully' => 'تم حذف  القسم بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'name'                => ' الاسم ',
        'type'                => ' النوع ',
];
