
<?php $__env->startSection('title'); ?>
 <?php echo e(__('kitchenrequests.titles.create')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <!-- Prism -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/prism/prism.css')); ?>" type="text/css">
    <!-- selectto -->
    <link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div>
            <h3> <?php echo e(__('kitchenrequests.titles.create')); ?> </h3>
            <?php echo $__env->make('admin.partials.breadcrumb',[
                'parent' => [
                    'name' => __("kitchenrequests.titles.create"),
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <h6 class="card-title"><?php echo e(__('kitchenrequests.titles.create')); ?></h6>
                            <form  method="POST"  action="<?php echo e(route('kitchenrequests.store')); ?>" >
                              <?php echo csrf_field(); ?>
                              <div class="form-group row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo e(__('kitchenrequests.material_id')); ?></label>
                                    <div class="col-sm-10">
                                    <select class="select2 " name="material_id">
                                        <option disabled  selected> اختر <?php echo e(__('kitchenrequests.material_id')); ?></option>
                                        <?php if($materials->count() > 0): ?>
                                            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  value="<?php echo e($material->id); ?>"> <?php echo e($material->name); ?> (<?php echo e($material->measuring->name); ?>) </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    </div>
                              </div>
                              <div class="form-group row">
                                    <label for="inputPassword" class="col-sm-2 col-form-label">
                                        <?php echo e(__('kitchenrequests.quantity')); ?>

                                    </label>
                                  <div class="col-sm-10">
                                    <input type="text" class="form-control" id="inputPassword" placeholder="<?php echo e(__('kitchenrequests.quantity')); ?>" value="<?php echo e(old('quantity')); ?>" name="quantity">
                                  </div>
                              </div>
                              <input type="hidden" value="<?php echo e(Auth::user()->employee->id); ?>" name="employee_id">
                              <div class="d-flex flex-row-reverse">
                                <button class="btn btn-primary " type="submit"><?php echo e(__('app.forms.btn.FormSubmit')); ?></button>
                              </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Form validation example -->
    <script src="<?php echo e(url('assets/js/examples/form-validation.js')); ?>"></script>
    <!-- Prism -->
    <script src="<?php echo e(url('vendors/prism/prism.js')); ?>"></script>
    <!-- selectto -->
    <script src="../../vendors/select2/js/select2.min.js"></script>
  <script>
    $('.select2').select2({
        placeholder: 'اختر'
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\resturant\resources\views/admin/kitchenrequests/create.blade.php ENDPATH**/ ?>