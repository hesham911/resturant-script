<nav aria-label="breadcrumb">

    <ol class="breadcrumb">

        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(settings::first()->name); ?></a></li>

        <?php if(isset($upParent)): ?>

        <li class="breadcrumb-item"><a href="<?php echo e(url('/'.$upParent['url'])); ?>"><?php echo e($upParent['name']); ?></a></li>

        <?php endif; ?>

        <?php if(isset($parent)): ?>

            <li class="breadcrumb-item"><a href="<?php echo e(url('/'.$parent['url'])); ?>"><?php echo e($parent['name']); ?></a></li>

        <?php endif; ?>

        

    </ol>

    <?php if(isset($name)): ?>

    <h3><?php echo e($name); ?></h3>

    <?php endif; ?>

</nav><?php /**PATH E:\projects\resturant\resources\views/admin/partials/breadcrumbs.blade.php ENDPATH**/ ?>