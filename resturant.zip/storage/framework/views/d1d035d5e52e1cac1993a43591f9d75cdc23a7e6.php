
<?php $__env->startSection('title'); ?>
<?php echo e(__('subcategories.titles.index')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <!-- Datatable -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-header d-md-flex justify-content-between">
        <div>
            <h3> <?php echo e(__('subcategories.titles.index')); ?> </h3>
            <?php echo $__env->make('admin.partials.breadcrumb',[
                'parent' => [
                    'name' => __("subcategories.titles.index"),
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <nav aria-label="breadcrumb" class="d-flex align-items-start">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Users</li>
                </ol>
            </nav>
        </div>
        <div class="mt-2 mt-md-0">
            <div class="dropdown ml-2">
                <a href="<?php echo e(route('subcategories.create')); ?>" class="btn btn-primary " ><?php echo e(__('subcategories.titles.create')); ?></a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table id="user-list" class="table table-lg">
                            <thead>
                            <tr>
                                <th>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="user-list-select-all">
                                        <label class="custom-control-label" for="user-list-select-all"></label>
                                    </div>
                                </th>
                                <th><?php echo e(__('app.tables.num')); ?></th>
                                <th> <?php echo e(__('subcategories.name')); ?></th>
                                <th class="text-right"> <?php echo e(__('app.tables.control')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php if($subcategories->count() > 0): ?>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td><?php echo e($category->id); ?></td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a href="#" data-toggle="dropdown"
                                                class="btn btn-floating"
                                                aria-haspopup="true" aria-expanded="false">
                                                    <i class="ti-more-alt"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a href="<?php echo e(route('subcategories.edit',$category->id)); ?>" class="dropdown-item"><?php echo e(__('app.tables.btn.edit')); ?></a>
                                                    <form method="POST" action="<?php echo e(route('subcategories.destroy',$category->id)); ?>"  >
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="_method" value="DELETE" >
                                                        <button class="dropdown-item text-danger" >
                                                            <?php echo e(__('app.tables.btn.delete')); ?>

                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Datatable -->
    <script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\resturant\resources\views/admin/subcategories/index.blade.php ENDPATH**/ ?>