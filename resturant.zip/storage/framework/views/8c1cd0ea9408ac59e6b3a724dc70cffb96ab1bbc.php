<ul>
    

    

    
    <li>
        
        <ul>
            
            
        </ul>
    </li> 
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-map-marker fa-2x"></i>
            </span>
            <span>التحكم في المناطق</span>
        </a>
        <ul>
            <li>
                <a href="#">المناطق</a>
                <ul>
                    <li>
                        <a href="<?php echo e(route('zones.index')); ?>">كل المناطق</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('zones.create')); ?>">إضافة منطقة جديدة</a>
                    </li>
                </ul>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> الأقسام</span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('categories'))? 'active' : ''); ?>" href="<?php echo e(route('categories.index')); ?>">عرض الكل</a>
            </li>
            <li>
                <a class="<?php echo e((request()->is('categories/create'))? 'active' : ''); ?>" href="<?php echo e(route('categories.create')); ?>">إضافة جديد</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> <?php echo e(__('subcategories.titles.index')); ?></span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('subcategories'))? 'active' : ''); ?>" href="<?php echo e(route('subcategories.index')); ?>">عرض الكل</a>
            </li>
            <li>
                <a class="<?php echo e((request()->is('subcategories/create'))? 'active' : ''); ?>" href="<?php echo e(route('subcategories.create')); ?>">إضافة جديد</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> <?php echo e(__('settings.titles.index')); ?></span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('settings'))? 'active' : ''); ?>" href="<?php echo e(route('settings.index')); ?>">عرض الكل</a>
            </li>
            <li>
                <a class="<?php echo e((request()->is('settings/create'))? 'active' : ''); ?>" href="<?php echo e(route('settings.create')); ?>">إضافة جديد</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> <?php echo e(__('materials.titles.index')); ?></span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('materials'))? 'active' : ''); ?>" href="<?php echo e(route('materials.index')); ?>">عرض الكل</a>
            </li>
            <li>
                <a class="<?php echo e((request()->is('materials/create'))? 'active' : ''); ?>" href="<?php echo e(route('materials.create')); ?>">إضافة جديد</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> <?php echo e(__('supplies.titles.index')); ?></span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('supplies'))? 'active' : ''); ?>" href="<?php echo e(route('supplies.index')); ?>">عرض الكل</a>
            </li>
            <li>
                <a class="<?php echo e((request()->is('supplies/create'))? 'active' : ''); ?>" href="<?php echo e(route('supplies.create')); ?>">إضافة جديد</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> <?php echo e(__('stocks.warehousestock')); ?></span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('warehousestock'))? 'active' : ''); ?>" href="<?php echo e(route('warehousestock.index')); ?>">عرض الكل</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> <?php echo e(__('productmanufactures.titles.index')); ?></span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('productmanufactures'))? 'active' : ''); ?>" href="<?php echo e(route('productmanufactures.index')); ?>">عرض الكل</a>
            </li>
            <li>
                <a class="<?php echo e((request()->is('productmanufactures/create'))? 'active' : ''); ?>" href="<?php echo e(route('productmanufactures.create')); ?>">إضافة جديد</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="#">
            <span class="nav-link-icon">
                <i class="fa fa-clipboard" ></i>
            </span>
            <span> <?php echo e(__('kitchenrequests.titles.index')); ?></span>
        </a>
        <ul>
            <li>
                <a class="<?php echo e((request()->is('kitchenrequests'))? 'active' : ''); ?>" href="<?php echo e(route('kitchenrequests.index')); ?>">عرض الكل</a>
            </li>
            <li>
                <a class="<?php echo e((request()->is('kitchenrequests/create'))? 'active' : ''); ?>" href="<?php echo e(route('kitchenrequests.create')); ?>">إضافة جديد</a>
            </li>
        </ul>
    </li>
</ul>
<?php /**PATH E:\projects\resturant\resources\views/admin/partials/menu.blade.php ENDPATH**/ ?>