<div class="header-container">
    <div class="header-left">
        <div class="navigation-toggler">
            <a href="#" data-action="navigation-toggler">
                <i data-feather="menu"></i>
            </a>
        </div>

        <div class="header-logo">
            <a href="<?php echo e(url('/')); ?>">
                <img class="logo" src="<?php echo e(url('assets/media/image/logo.png')); ?>" alt="logo">
            </a>
        </div>
    </div>
    <div class="header-body">
        <div class="header-body-left">
            <ul class="navbar-nav">
                <li class="nav-item mr-3">
                    <div class="header-search-form">
                        
                    </div>
                </li>
            </ul>
        </div>

        <div class="header-body-right">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="#" class="nav-link mobile-header-search-btn" title="Search">
                        <i data-feather="search"></i>
                    </a>
                </li>

                <li class="nav-item dropdown d-none d-md-block">
                    <a href="#" class="nav-link" title="Fullscreen" data-toggle="fullscreen">
                        <i class="maximize" data-feather="maximize"></i>
                        <i class="minimize" data-feather="minimize"></i>
                    </a>
                </li>

                
            </ul>
        </div>
    </div>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item header-toggler">
            <a href="#" class="nav-link">
                <i data-feather="arrow-down"></i>
            </a>
        </li>
    </ul>
</div>
<?php /**PATH E:\projects\resturant\resources\views/admin/partials/header.blade.php ENDPATH**/ ?>