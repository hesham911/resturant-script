<nav aria-label="breadcrumb" class="d-flex align-items-start">
    <ol class="breadcrumb">
        <!-- settings::first()->name -->
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">الرئيسية</a></li>
        <?php if(isset($upParent)): ?>
            
            <li class="breadcrumb-item"><a href="<?php echo e(route($upParent['url'])); ?>"><?php echo e($upParent['name']); ?></a></li>
        <?php endif; ?>
        <?php if(isset($parent)): ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($parent['name']); ?></li>
            
        <?php endif; ?>
        
    </ol>
    
</nav>
<?php /**PATH E:\projects\resturant\resources\views/admin/partials/breadcrumb.blade.php ENDPATH**/ ?>