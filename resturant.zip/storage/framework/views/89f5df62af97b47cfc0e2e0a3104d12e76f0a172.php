
<?php $__env->startSection('title'); ?>
    <?php echo e(__('geo.zones.titles.create')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <!-- Prism -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/prism/prism.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div>
            <h3><?php echo e(__('geo.zones.titles.create')); ?></h3>
            <?php echo $__env->make('admin.partials.breadcrumb',[
                'parent' => [
                    'name' => __("geo.zones.titles.create"),
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-body">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <h6 class="card-title"><?php echo e(__('geo.zones.titles.subcreate')); ?></h6>
                            <form method="post" action="<?php echo e(route('zones.store')); ?>" multiple>
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="name" class="col-sm-2 col-form-label"><?php echo e(__('geo.zones.name')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" id="name" placeholder="<?php echo e(__('geo.zones.placeholder.name')); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="price" class="col-sm-2 col-form-label"><?php echo e(__('geo.zones.price')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" name="price" value="<?php echo e(old('price')); ?>" class="form-control" id="price" placeholder="<?php echo e(__('geo.zones.placeholder.price')); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('app.forms.btn.add')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Form validation example -->
    <script src="<?php echo e(url('assets/js/examples/form-validation.js')); ?>"></script>

    <!-- Prism -->
    <script src="<?php echo e(url('vendors/prism/prism.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\resturant\resources\views/admin/geo/zones/create.blade.php ENDPATH**/ ?>