<?php

return [
    'forms'     => [
        'btn'      =>[
            'FormSubmit'            => ' تأكيد ',
            'edit'                  => ' تعديل ',
            'add'                   => ' إضافة ',
            'delete'                => ' حذف ',
        ],
    ],
    'tables'    =>[
        'control'  => 'التحكم',
        'num'      => 'التسلسل'
    ]

];