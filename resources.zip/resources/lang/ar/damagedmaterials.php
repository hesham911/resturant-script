<?php

return [
        'titles'        => [
            'index'     => '  التلفيات ',
            'create'    => ' إضافة  تلفيات ',
            'edit'      => 'تعديل   التلفيات  ',
            'show'      => ' عرض   التلفيات  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل   تلفيات   بنجاح',
            'updated_succesfully' => 'تم تعديل   التلفيات بنجاح',
            'deleted_succesfully' => 'تم حذف   التلفيات بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
            'null_kitchen_request'       => 'المادة الخام المطلوبة غير موجودة في المخزن',
            'insufficient_kitchen_request'       => 'لا يوجد رصيد كافي بالمخزن',
        ],
        'employee_id'                => ' الموظف ',
        'material_id'                => ' المادة الخام ',
        'quantity'                => ' الكمية ',
        'price'                => ' اجمالي التكلفة  ',
];
