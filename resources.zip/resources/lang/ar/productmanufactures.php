<?php

return [
        'titles'        => [
            'index'     => ' مواد التصنيع   ',
            'create'    => ' إضافة مادة تصنيع ',
            'edit'      => 'تعديل  مادة التصنيع  ',
            'show'      => ' عرض  مادة التصنيع  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل  مادة تصنيع    بنجاح',
            'updated_succesfully' => 'تم تعديل  مادة التصنيع بنجاح',
            'deleted_succesfully' => 'تم حذف  مادة التصنيع بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'material_id'             => ' المادة الخام ',
        'required_quantity'       => ' الكمية  ',
        'waste_percentage'        => '  نسبة الفقد   ',
        'product_id'              => '  المنتج   ',
];
