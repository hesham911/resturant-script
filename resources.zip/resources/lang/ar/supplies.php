<?php

return [
        'titles'        => [
            'index'     => ' توريدات المخزن   ',
            'create'    => ' إضافة أمر توريد ',
            'edit'      => 'تعديل  أمر التوريد  ',
            'show'      => ' عرض  أمر التوريد  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل  أمر توريد    بنجاح',
            'updated_succesfully' => 'تم تعديل  أمر التوريد بنجاح',
            'deleted_succesfully' => 'تم حذف  أمر التوريد بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'material_id'             => ' المادة الخام ',
        'quantity'                => ' الكمية  ',
        'price'                   => '  السعر   ',
        'Supplier_name'           => '  المورد   ',
        'expiry_date'             => '  تاريخ الصلاحية   ',
        'user_id'                 => '  المستخدم  ',
        'measuring_id'            => '  الوحدة  ',
        'status'                  => ' الحالة ',
        'used_amount'             => '  الكمية المستهلكة  ',
        'employee_id'             => '  الموظف  ',
        'bill_number'             => '  رقم الفاتورة   ',
];
