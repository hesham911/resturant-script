<?php

return [
        'titles'        => [
            'index'     => ' رصيد   ',
            'create'    => ' إضافة رصيد ',
            'edit'      => 'تعديل  الرصيد  ',
            'show'      => ' عرض  الرصيد  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل  رصيد   بنجاح',
            'updated_succesfully' => 'تم تعديل  الرصيد بنجاح',
            'deleted_succesfully' => 'تم حذف  الرصيد بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'material_id'             => ' المادة الخام ',
        'quantity'                => ' الكمية  ',
        'measuring_id'             => '   وحدة القياس  ',
        'warehousestock'             => '  رصيد المخزن  ',
        'kitchenstock'             => '  رصيد المخزن  ',
];
