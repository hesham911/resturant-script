<?php

return [
        'titles'        => [
            'index'     => ' المواد الخام ',
            'create'    => ' إضافة مادة خام ',
            'edit'      => 'تعديل  المادة الخام  ',
            'show'      => ' عرض  المادة الخام  ',
        ],
        'massages' => [
            'created_succesfully' => 'تم  تسجيل  مادة خام   بنجاح',
            'updated_succesfully' => 'تم تعديل  المادة الخام بنجاح',
            'deleted_succesfully' => 'تم حذف  المادة الخام بنجاح',
            'error_occured'       => 'حدث خطأ من فضلك راجع البيانات المطلوبة',
        ],
        'name'                    => ' الاسم ',
        'expiry_date'             => ' تاريخ الصلاحية ',
        'measuring_id'            => ' وحدة القياس',
];
